package com.example.my_browser

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
